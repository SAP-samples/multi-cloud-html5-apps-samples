sap.ui.define([
  "com/myorg/FLP/controller/BaseController"
], function(Controller) {
  "use strict";

  return Controller.extend("com.myorg.FLP.controller.MainView", {});
});
